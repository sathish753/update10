const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const DB_FILE = path.join(__dirname, 'data', 'db.json');
const ARCHIVE_DIR = path.join(__dirname, 'data', 'archive');

// ---- audit log rotation settings ----
// Live audit log keeps the current month + 2 prior months (3 months live).
// Once an entry's month turns 3 months old it is moved (bumped) into a
// monthly archive file under data/archive/. Archive files are kept for a
// further 3 months (so a Jan entry: lives Jan-Mar, bumped to archive in
// Apr, deleted once it reaches Jul) — matches the "archive on the 4th
// month, delete after ~6 months" retention window.
// NOTE: this only rotates auditLog entries. state.records (the live
// mapping/field data) is never touched by rotation — current data always
// stays fully intact and recoverable regardless of log age.
const ARCHIVE_AFTER_MONTHS = 3;
const DELETE_AFTER_MONTHS = 6;

// ---- default seed data (used only the very first time the app runs) ----
function seedData() {
  return {
    users: [
      { id: 'u1', username: 'admin', password: bcrypt.hashSync('admin123', 12), role: 'admin', displayName: 'Administrator' },
      { id: 'u2', username: 'om1', password: bcrypt.hashSync('om123', 12), role: 'om', displayName: 'OM User' },
      { id: 'u3', username: 'tl1', password: bcrypt.hashSync('tl123', 12), role: 'tl', displayName: 'TL User' }
    ],
    records: [],
    auditLog: [],
    standby: [],
    nextSno: 1
  };
}

// ---- load / init ----
function load() {
  if (!fs.existsSync(DB_FILE)) {
    const initial = seedData();
    fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2));
    return initial;
  }
  const raw = fs.readFileSync(DB_FILE, 'utf-8');
  try {
    const parsed = JSON.parse(raw);
    // back-compat: older db.json files predate the Standby Box feature
    if (!Array.isArray(parsed.standby)) parsed.standby = [];
    return parsed;
  } catch (e) {
    console.error('DB file corrupt, reinitializing with seed data.', e);
    const initial = seedData();
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2));
    return initial;
  }
}

let state = load();

// simple write queue so concurrent requests never interleave writes
let writeChain = Promise.resolve();
function persist() {
  writeChain = writeChain.then(() => new Promise((resolve, reject) => {
    fs.writeFile(DB_FILE, JSON.stringify(state, null, 2), (err) => {
      if (err) return reject(err);
      resolve();
    });
  }));
  return writeChain;
}

// ---- audit log archiving (bump) ----
function ymOf(timestamp) {
  return (timestamp || '').slice(0, 7); // 'YYYY-MM'
}

function monthAge(ymStr, ref) {
  const parts = (ymStr || '').split('-').map(Number);
  const y = parts[0], m = parts[1];
  if (!y || !m) return 0;
  const refY = ref.getFullYear(), refM = ref.getMonth() + 1;
  return (refY * 12 + refM) - (y * 12 + m);
}

// Moves audit log entries older than ARCHIVE_AFTER_MONTHS out of the live
// db.json into data/archive/audit-YYYY-MM.json, grouped by month. Safe to
// call repeatedly — merges into existing archive files without duplicating
// entries (matched by id).
function rotateAuditLog() {
  const now = new Date();
  const keep = [];
  const toArchive = {};

  (state.auditLog || []).forEach(entry => {
    const ym = ymOf(entry.timestamp);
    if (ym && monthAge(ym, now) >= ARCHIVE_AFTER_MONTHS) {
      (toArchive[ym] = toArchive[ym] || []).push(entry);
    } else {
      keep.push(entry);
    }
  });

  const months = Object.keys(toArchive);
  if (months.length === 0) return false;

  fs.mkdirSync(ARCHIVE_DIR, { recursive: true });
  months.forEach(ym => {
    const file = path.join(ARCHIVE_DIR, `audit-${ym}.json`);
    let existing = [];
    if (fs.existsSync(file)) {
      try { existing = JSON.parse(fs.readFileSync(file, 'utf-8')); } catch (e) { existing = []; }
    }
    const existingIds = new Set(existing.map(e => e.id));
    const merged = existing.concat(toArchive[ym].filter(e => !existingIds.has(e.id)));
    fs.writeFileSync(file, JSON.stringify(merged, null, 2));
  });

  state.auditLog = keep;
  console.log(`[archiver] bumped audit log for month(s): ${months.join(', ')} -> data/archive/`);
  return true;
}

// Deletes archive files once they're DELETE_AFTER_MONTHS old (from the
// month the entries actually happened in, not from when they were archived).
function purgeOldArchives() {
  if (!fs.existsSync(ARCHIVE_DIR)) return;
  const now = new Date();
  fs.readdirSync(ARCHIVE_DIR).forEach(file => {
    const match = file.match(/^audit-(\d{4}-\d{2})\.json$/);
    if (!match) return;
    if (monthAge(match[1], now) >= DELETE_AFTER_MONTHS) {
      fs.unlinkSync(path.join(ARCHIVE_DIR, file));
      console.log(`[archiver] deleted expired archive file: ${file}`);
    }
  });
}

function runMaintenance() {
  const changed = rotateAuditLog();
  purgeOldArchives();
  if (changed) persist();
}

// run once at startup, then daily — rotation only ever moves whole
// calendar months so daily granularity is more than enough.
runMaintenance();
setInterval(runMaintenance, 24 * 60 * 60 * 1000);

module.exports = {
  get state() { return state; },
  persist,
  runMaintenance,
  genId(prefix) {
    return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }
};
