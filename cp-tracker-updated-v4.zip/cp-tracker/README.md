# CP / Workstation Ledger

A Node.js + Express web app for maintaining the employee ↔ workstation ↔ CP mapping
register, with three role-based logins and a built-in audit dashboard.
**No external database** — all data is stored in a single JSON file on disk
(`data/db.json`), which is created automatically the first time the server runs.

## Table fields
S.No, Employee Name, Employee ID, Block, Workstation Number, CP Name,
Process Name, Client Name, TL Name, OM Name.

## Roles

| Role  | Can view all records | Can create / delete records | Can edit |
|-------|:---:|:---:|---|
| Admin | ✅ | ✅ | All fields, including mapping any of the above |
| OM    | ✅ | ❌ | Everything except Block, Workstation Number, OM Name, and CP Name |
| TL    | ✅ | ❌ | Employee Name, Employee ID, Process Name, Client Name |

Field-level permission is enforced on the **server**, not just hidden in the UI —
an OM or TL account cannot push a change to a field it isn't allowed to touch,
even by calling the API directly.

## Mapping count
Per employee/record, the mapping count increments by 1 whenever:
- CP Name is added, updated, modified, deleted, or cleared
- Employee ID is added, updated, or modified (clearing Employee ID alone does not increment it)

## Standby Box (admin only)
A holding pool for CPs that are currently unassigned to any employee. Admins
can pull a CP off a live record straight into Standby (clearing it off that
record, which counts as a normal CP-clear mapping event), add a free-standing
CP directly, remove a CP from Standby outright, or map a Standby CP onto an
employee's record (a normal, counted CP change). Standby moves themselves are
always written to the audit trail but never add to the mapping count on their
own — only an actual CP Name/Employee ID change on a record does.

Each Standby entry ages by calendar day since it entered the box:
- 🟢 Day 1 — newly added
- 🟡 Day 2 — aging
- 🔴 Day 3+ — stays red until it's mapped out or otherwise manually changed

If a CP is later removed from Standby and mapped again, and eventually
returns to Standby, it gets a fresh entry and its color resets to Day 1.

**Auto-return:** whenever a record's CP Name is replaced or cleared — either
by directly editing the record, or by mapping a different CP onto it from
Standby — the CP that used to be there is automatically sent back into the
Standby Box as a brand-new (Day 1/green) entry. You don't need to manually
re-add it. Example: CP-01 is mapped to A/9; later you edit that record and
retype the CP Name to CP-09 — CP-01 reappears in the Standby list on its own,
freshly dated.

## Change dashboard
Every time **CP Name**, **Employee Name** or **Employee ID** is changed on a
record, an audit entry is written with the old value, new value, who made the
change, their role and a timestamp. The "Change Dashboard" tab shows:
- totals (records, tracked interchanges, changes today, all changes)
- a breakdown of interchanges by field
- the S.No entries that have been re-assigned the most
- a full audit trail table with before → after values

## Getting started (local)

```bash
npm install
npm start
```

The server starts on `http://localhost:3000` (or `PORT` from the environment).

### Demo logins (change these immediately in a real deployment)

| Role  | Username | Password |
|-------|----------|----------|
| Admin | admin    | admin123 |
| OM    | om1      | om123    |
| TL    | tl1      | tl123    |

Once logged in as Admin, go to **Manage Logins** to create real accounts and
remove the demo ones.

## Deploying

This is a plain Node/Express app — deploy it anywhere that runs Node.js
(a VPS, Render, Railway, an on-prem server, etc.):

1. Copy the project to the server (excluding `node_modules` and `data/db.json`).
2. `npm install --production`
3. Set a real session secret: `export SESSION_SECRET="something-long-and-random"`
4. `npm start` (or run it under a process manager like `pm2` / `systemd` so it
   restarts automatically).
5. Point a reverse proxy (nginx / Caddy) at the app's port if you need HTTPS
   on a domain.

### Persisting data
All data lives in `data/db.json`. **Back this file up regularly** — it is the
entire database. Since it's a single file, avoid running multiple instances
of the app against the same `data/` folder behind a load balancer; run one
Node process (pm2's cluster mode would cause writes to race).

## Project structure
```
cp-tracker/
├── server.js        # Express app, auth, permissions, API routes
├── db.js             # JSON-file data layer (the "built-in DB")
├── data/db.json       # created automatically on first run
├── public/
│   ├── index.html    # SPA shell (login + records + dashboard + users)
│   ├── style.css
│   └── app.js         # frontend logic (fetch calls to the API)
└── package.json
```
